<section class="vbox">
            <section class="scrollable padder">
              <ul class="breadcrumb no-border no-radius b-b b-light pull-in">
                <li><a href="index.php"><i class="fa fa-home"></i> Home</a></li>
                <li class="active">Grab</li>
              </ul>
             
			  <section class="panel panel-default">
                <header class="panel-heading font-bold">
                  Grab multi
                </header>
                <div class="panel-body">
                  <form class="form-horizontal" method="post" action="index.php?act=addmulti">
				  <div class="form-group">
                      <label class="col-sm-2 control-label">Danh sách</label>
					  <div class="col-sm-10"> <select name="webgrab" class="form-control m-b">
<option value="phimhdvn">PhimHD.vn</option>
<option value="phimh">VNHD.net</option>
<option value="biphim">BiPhim.com</option>
<option value="phimnhanh">PhimNhanh.com</option>
<option value="phimmedia">Phim.Media</option>							
									<option value="phimtructuyenhd">PhimTrucTuyenHD.com</option>
									<option value="phimmoi">PhimMoi.net</option>
									<option value="phim14">Phim14.net</option>
									<option value="phimvipvn">PhimVipVN.net</option>
									<option value="megabox">Phim.Megabox.Vn</option>
									
								</select></div>
                    </div>
                    <div class="line line-dashed line-lg pull-in"></div> 
					<div class="form-group">
                      <label class="col-sm-2 control-label">Link phim:</label>
					  <div class="col-sm-10"><input type="text" name="urlgrab" size="50" value="" class="form-control rounded"></div>
                    </div>
                   
                    <div class="line line-dashed line-lg pull-in"></div><div class="form-group">
                      <div class="col-sm-4 col-sm-offset-2">
                        <button type="submit" name="ok" class="btn btn-primary">Grab</button>
                      </div>
                    </div>
   <div class="line line-dashed line-lg pull-in"></div><div class="form-group">
<label class="col-sm-2 control-label">Url support:</label>
                      <div class="col-sm-10 col-sm-offset-2">
                      + http://www.phimmoi.net/phim/bay-tinh-yeu-3577/ <br />
                      + http://mphim.net/phim/chu-cho-oddball-oddball-and-the-penguins-2015.html <br />
 + http://biphim.com/phim-le/duong-nhu-da-yeu_6839/ <br />
 + http://phim14.net/phim/vong-xoay-hanh-phuc.8151.html <br />
 + http://vnhd.net/phim/bac-thay-thuong-gia/9638.html <br />
 + http://phimnhanh.com/phim/chu-cho-oddball-oddball-and-the-penguins-2015<br />
+ http://phimvipvn.net/7-vien-ngoc-rong-phan-moi-dragon-ball-super.7929/
                    </div>
                  </form>

                </div>
              </section>
			 </section>
          </section>