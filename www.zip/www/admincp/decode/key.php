<?php 
	$key_phim4v = 'mp4ldhjn01ge3pgm5hdv';
	$key_phimdata = 'gy45htnvym89sne5hdkw';
	$key_xemvn = 'Kas5PQWx3mvns9XyHKFv';
	$key_phim79 = 'KrfkAXQFDJidBFQPEwoa';
?>