﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'about', 'ar', {
	copy: 'حقوق النشر &copy; $1. جميع الحقوق محفوظة.',
	dlgTitle: 'عن CKEditor',
	help: 'راجع $1 من أجل المساعدة',
	moreInfo: 'للحصول على معلومات الترخيص ، يرجى زيارة موقعنا:',
	title: 'عن CKEditor',
	userGuide: 'دليل مستخدم CKEditor.'
} );
