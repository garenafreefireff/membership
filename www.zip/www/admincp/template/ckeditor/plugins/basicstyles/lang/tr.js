﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'basicstyles', 'tr', {
	bold: 'Kalın',
	italic: 'İtalik',
	strike: 'Üstü Çizgili',
	subscript: 'Alt Simge',
	superscript: 'Üst Simge',
	underline: 'Altı Çizgili'
} );
