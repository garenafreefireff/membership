﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'basicstyles', 'pt', {
	bold: 'Negrito',
	italic: 'Itálico',
	strike: 'Rasurado',
	subscript: 'Superior à linha',
	superscript: 'Inferior à Linha',
	underline: 'Sublinhado'
} );
