﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'basicstyles', 'zh-cn', {
	bold: '加粗',
	italic: '倾斜',
	strike: '删除线',
	subscript: '下标',
	superscript: '上标',
	underline: '下划线'
} );
