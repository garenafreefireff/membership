﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'basicstyles', 'ar', {
	bold: 'عريض',
	italic: 'مائل',
	strike: 'يتوسطه خط',
	subscript: 'منخفض',
	superscript: 'مرتفع',
	underline: 'تسطير'
} );
