<?
$html .= '<div class="column medium-4 margin-bottom-5px">
				
			<div class="column medium-12 small-5 ratio16_9">
				<div class="box">
					<span class="video-time">'.$videoDURATION.'</span>
					<a href="'.$videoURL.'" 
						title="Video clip '.$videoNAME.'">
						<img alt="Video clip '.$videoNAME.'" src="'.$videoIMG.'">
						<div class="description-clip">'.$videoNAME.'</div>
					</a>
				</div>
			</div>
			<div class="column medium-12 small-7 video-detail">
				<a href="'.$videoURL.'" 
					title="Video clip '.$videoNAME.'"><strong>'.$videoNAME.'</strong></a>
				<div class="metadata-clip">
					<span class="user-icon">'.$videoPOSTER.'</span>
					<span class="play-icon">'.$videoVIEWED.'</span>
				</div>
			</div>
 		
	</div>';
?>