<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<title>Error 404 - Page Not Found</title>
<style>
body, html {
	background: none repeat scroll 0 0 #f9f9f9;
    color: #333333;
    font-family: 'Trebuchet MS',Helvetica,Arial,sans-serif;
    font-size: 12px;
    height: 100%;
}
h1{font-weight:500;font-size:20px;margin:3px 0;}
h3{margin:3px 0;font-size:16px;font-weight:normal;}
a {
	font-weight:bold;
	color:#333;
	text-decoration:underline;
}
</style>
</head>

<body>
<h1><strong>Error 404</strong>: Không tìm thấy trang</h1>
<p>Click <a href="http://www.phimle.tv/">here</a> to back to the home page.</p>
</body>
</html>
