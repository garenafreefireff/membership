<?php 
$html .= '<a href="'.$filmURL.'" title="'.$filmNAMEVN.' - '.$filmNAMEEN.'" class="item _trackLink"><img src="'.$filmIMGSlide.'" alt="'.$filmNAMEVN.' - '.$filmNAMEEN.'" /><span class="status"><p>Phim '.$filmNAMEVN.'</p><p>Tên tiếng anh: '.$filmNAMEEN.' ('.$filmYEAR.')</p><p>Trạng thái: '.$Status.'</p></span></a>';
?>