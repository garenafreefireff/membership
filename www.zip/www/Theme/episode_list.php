<div class="epi">
    <div style="padding-top:8px;"><b><?=ServerNAME($i);?>:</b>
     	<?=$sv[$i];?>
		<br/>
	</div>
</div>