<?php
$html .='<div class="item col-lg-3 col-md-3 col-sm-6 col-xs-6">
                                        <div class="inner">
                                            <a class="poster" href="'.$videoLINK.'" title="'.$videoNAME.'"> 
											<img src="'.$videoIMG.'" alt="'.$videoNAME.'"> </a> <a class="name" href="'.$videoLINK.'" title="'.$videoNAME.'">'.$videoNAME.'</a> <dfn>'.$videoDURATION.'</dfn></div>
                                    </div>';
?>
