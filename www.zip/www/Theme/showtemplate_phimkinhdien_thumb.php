<?php
$html .= '<li class="dot" data-ord="'.$z.'"><img src="'.thumbimg($filmIMG,45).'" alt="'.$filmNAMEVN.' - '.$filmNAMEEN.'" /></li>';
?>