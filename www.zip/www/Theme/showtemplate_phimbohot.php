<?php
$html .= '<a title="'.$filmNAMEVN.' - '.$filmNAMEEN.'" href="'.$filmURL.'"><img src="'.$filmIMGBN.'" alt="'.$filmNAMEVN.' - '.$filmNAMEEN.'" border="0"><span><h3>'.$filmNAMEVN.'</h3><h4>'.$filmNAMEEN.' ('.$filmYEAR.')</h4></span></a>';
?>