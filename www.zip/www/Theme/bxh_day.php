
<?php
$html .= '<li>
                    <div class="TPost A">
                              <a rel="bookmark" href="'.$filmURL.'"> <span class="Top">#'.$z.'<i></i></span>
                                 <div class="Image">
                                    <figure class="Objf TpMvPlay AAIco-play_arrow">
                                       <img width="55" height="85" src="'.$filmIMG.'" class="attachment-img-mov-sm size-img-mov-sm wp-post-image" alt="'.$filmNAME.' ('.$filmYEAR.')"></figure>
                                 </div>
                                 <div class="Title">'.$filmNAME.'</div>
                              </a>
                              <p class="Info">
                               <span class="Vote AAIco-star">'.$filmRATE.'</span>
                               <span class="Time AAIco-access_time">'.$filmTIME.'</span> 
                               <span class="Date AAIco-date_range">'.$filmYEAR.'</span> 
                               <span class="Qlty">'.$filmQUALITY.'</span></p>
                           </div>
                        </li>';



?>