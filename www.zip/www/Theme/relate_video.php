<div class="col-lg-12 col-md-4 col-sm-4 col-xs-12">
    <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
        <a href="<?=$videoLINK;?>"><img alt="<?=$videoNAME;?>" src="<?=$videoIMG;?>"></a>
    </div>
    <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
        <p class="namevn"><a href="<?=$videoLINK;?>"><?=$videoNAME;?></a></p>
        <p><?=$language['view'];?>: <?=$videoVIEWED;?></p>
        
    </div>
</div>