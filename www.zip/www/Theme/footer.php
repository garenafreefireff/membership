<footer class="Footer">
    <div class="Container">
        <div class="MnBrCn BgA">
            <div class="MnBr EcBgA">
                <div class="Container">
                    <figure class="Logo">
                        <a href="<?=$web_link;?>" title="Anime Hay HD | Anime Vietsub | Xem Anime Vietsub HD Online | Hoạt Hình Vietsub | Xem Anime | Xem Anime Vietsub Miễn Phí Siêu Nhanh" rel="home">
                            <img title="Anime Hay HD | Anime Vietsub | Xem Anime Vietsub HD Online | Hoạt Hình Vietsub | Xem Anime | Xem Anime Vietsub Miễn Phí Siêu Nhanh" src="<?=$web_link;?>/favicon.ico" alt="Anime Hay HD | Anime Vietsub | Xem Anime Vietsub HD Online | Hoạt Hình Vietsub | Xem Anime | Xem Anime Vietsub Miễn Phí Siêu Nhanh">
                        </a>
                    </figure>
                    <div class="Rght">
                        <nav class="Menu">
                            <ul>
                                <li class="menu-item menu-item-type-custom menu-item-object-custom current-menu-item menu-item-home menu-item-490"><a href="<?=$web_link;?>">Trang Chủ</a></li>
                                <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-493"><a href="<?=$web_link;?>/page/thuat-ngu.html">THUẬT NGỮ</a></li>
                                <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-493"><a href="<?=$web_link;?>/page/dmca.html">DMCA</a></li>
                                <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-493"><a href="<?=$web_link;?>/page/chinh-sach-rieng-tu.html">CS RIÊNG TƯ</a></li>
                                <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-493"><a href="<?=$web_link;?>/page/dieu-khoan-su-dung.html">ĐIỀU KHOẢN SỬ DỤNG</a></li>
                            </ul>
                        </nav>
                        <ul class="ListSocial">
                            <li>
                                <a target="_blank" href="" class="fa-facebook"></a>
                            </li>
                            <li>
                                <a target="_blank" href="https://twitter.com/" class="fa-twitter"></a>
                            </li>
                            <li>
                                <a target="_blank" href="https://google.com/" class="fa-google-plus"></a>
                            </li>
                            <li>
                                <a target="_blank" href="https://youtube.com/" class="fa-youtube-play"></a>
                            </li>
                            <li>
                                <a href="javascript:void(0)" class="Up AAIco-arrow_upward" title="Cuộn lên trên"></a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="WebDescription">
         <? require_once("hot_tags_home.php");?>
        </div>
        <p class="Copy">
            <a target="_blank" href="<?=$web_link;?>">Copyright ® 2019 HTAVN. All Rights Reserved. </a> Mọi dữ liệu trên AnimeHayHD đều được tổng hợp từ internet.
        </p>
    </div>
</footer>