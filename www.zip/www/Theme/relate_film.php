<div class="TPostMv">
    <div class="TPost B">
        <a href="<?=$filmURL;?>">
            <div class="Image">
               <figure class="Objf TpMvPlay AAIco-play_arrow"><img width="215" height="320" src="<?=$filmIMG;?>" class="attachment-thumbnail size-thumbnail wp-post-image" alt="<?=$filmNAMEVN;?> - <?=$filmNAMEVN;?> (<?=$filmYEAR;?>)" title="<?=$filmNAMEVN;?> - <?=$filmNAMEEN;?> (<?=$filmYEAR;?>)" /></figure>
			     <?=$Status;?>
					<div class="Title"><?=$filmNAMEVN;?></div>
                      </div>
                          </a>
                        </div>        
					  </div>