<?php
$html .= ' <li><a href="'.$filmURL.'" title="Xem Anime '.$filmNAME.'"><span>'.$filmNAME.'</span><span>'.$filmTONG.' Tập</span></a></li>';

?>